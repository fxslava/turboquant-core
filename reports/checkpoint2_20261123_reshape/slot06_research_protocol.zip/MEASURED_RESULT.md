# Slot06 measured outcome

The isolated six-strip CAModel run is functionally correct, but total ticks
regress: 64552 vs baseline64266 (+286, +0.445%). The full K/V byte, scale and
canary checks passed in the coordinator's run. This is a pure per-owner-credit
ablation, retaining inherited GM metadata loads and the original tensor VFs.

The exact protocol audit covers150 cross waits with0 release violations.
AIC ready8/9 each24, join0 once; free10/15 waits each26. Each AIV contributes
free10/15 each26, consumes ready8/9 each24 and join0 once. All HardEvent routes
balance. Both dummy MTE2 marker ledgers have26 SET/26 WAIT, maximum pending2,
and terminal0. The48 nonowner MTE2 notification waits have observed issue-to-
following-marker completion intervals1..5316ticks (median778); these are queued
engine readiness intervals, not scalar instruction service or scalar blockage.
No added MTE2_S1/3 scalar window WAIT has repeated CCU issue attempts.

Egress endpoints are18898,24747,33397,41972,50511,63864. Consecutive intervals:
5849,8650,8575,8539,13353. The last two interior intervals give a finite-probe
estimate8557ticks/strip versus baseline8722; the compiled tail interval13353
is excluded. This interior improvement does not outweigh the full-run change.
AIV1 is the final retiring participant64161, after AIV062543 and AIC59493.
This identifies the final participating role, not a fully reconstructed new
max-plus causal graph or proof that all earlier Cube work is off critical path.

Twelve long ZEROEXT retry intervals are bound to the actual preceding B32 load
of its source register and a DCache MISS at that load PC: AIV0 totals2654ticks,
AIV1 totals2764, vs baseline2683/2964. Short1tick retries are separate. This is
inherited per-strip slot_mapping dependency behavior. Other conspicuous scalar
retry classes are already present in baseline: AIC initialization CMP786;
AIV initialization control-stack store585/617 vs582/614; final OR245/246 vs
baseline244/247/245 across roles. No new tensor VF spill/data path exists:26
shared nonentry VF instruction byte streams remain identical. Small control
instruction retry changes and dispatch queue spans are retained in the raw
JSON evidence and are not mislabeled as hidden GM stalls.

Evidence: trace_protocol_audit.json, dynamic_audit.json (load-register/DC-MISS
certificates included), baseline_scalar_comparison.json, PRE_SIM_MANIFEST.json,
branch_certificate.json, fence_real_publications.json. Kernel source remains
SHA de71e0425801e2531b6eded86e4f58dd720873c3d7c61cb44bcd4fd6a6c50e95.
No physical NPU claim or promotion follows this result.
