# Slot 06: per-owner credit review

Status: **mode-4 branch rejected; mode-2 per-owner prototype compiled and ready for coordinator pre-simulator review**.
No baseline, verified Wave-v11 file, compiler job or simulator job was changed.

The source graph would use one two-slot landing ring per AIV. For owner `o`,
generation `g`, slot `g % 2`:

1. The AIC waits for that owner's slot-free notification, writes the panel,
   drains FIX to scalar, and publishes that owner's ready notification.
2. The owning AIV waits for ready, drains Vector to scalar, copies landing to
   its private work buffer, drains that read, and returns slot-free.
3. The other AIV is absent from this chunk's readiness condition. The AIC
   consumes the two final free credits per owner, drains its engines, then
   publishes one join notification per owner. Both AIVs consume their joins.

Mode 4 is the documented direct per-owner mechanism. Proposed local IDs are
ready `0,1`, free `2,3`, join `4`; AIC addresses owner 1 at local ID +16.
All IDs are inside legal local `0..10`; reserved `11..14` are untouched.
All publication fences remain. The strip grinder can retain its existing
eight compile-time phases and separate tail without per-strip branching.

## Three pre-simulator reviews

| Iteration | Check | Finding |
|---|---|---|
| 1 | 950PR API, ID map, ownership and source fence order | The graph is expressible with documented mode-4 APIs and five local IDs. No new UB is needed. |
| 2 | Executable capacity-one model, buffer generation ownership, prime/drain | Exhaustive consuming-counter model passes at 1/2/6 strips: 727/1567/4927 states. Sticky notification semantics fail with a concrete overwrite/stale-generation witness after 156 states. |
| 3 | Match semantic assumption to retained CAModel evidence | **Rejected**: `reports/bf16_prefill_key_plane_fix.md` records a recycled mode-4 failure despite every announcement being scalar-fenced. AIV1 consumed stale readiness and corrupted chunks 5 and 7. The consuming semantic assumption is not established for the current CANN 9.2.1 runtime. |

The model is `ownership_model.py`; `ownership_results.json` retains the
counterexample schedule and complete explored state counts. It proves a
conditional protocol property over bounded interleavings, not hardware flag
semantics. It has no tensor arithmetic, but is a host verification model,
not proposed device scalar data-loop code.

The retained report's mode-4 single-shot control passed. That mechanism does
not scale to the required probe: six strips contain 24 chunks per owner,
requiring at least 24 distinct ready channels per owner before counting
free channels and joins, against only 11 legal local IDs. Reusing IDs on
the assumption that they consume would repeat the refuted protocol.

No documented cross-core explicit clear/reset API was found in the local
synchronization corpus or audited signature catalog. This is a search result,
not proof that every CANN internal mechanism is absent. A source-backed reset
mechanism or fresh isolated consumption evidence would be needed to reopen
this design. A new counting protocol must additionally prove outstanding
credit bounds and cross-launch zero marking.

## Mode-2 alternative, source revision de71e0425801

The candidate now staged at
`/home/dmin/work/checkpoint2_20261123/slot06/src` uses documented mode-2
counting semantics. Ready channels are owner 0 = 8 and owner 1 = 9;
free channels are 10 and 15; the final join is 0. Each owner supplies its real
free contribution only after the landing-read `V_S` drain. The other AIV
supplies a structural dummy contribution before its own heavy work. The dummy
reports no tensor readiness. Each ready broadcast is consumed by its actual
owner on Vector and by the nonowner on otherwise-unused MTE2.

An unbounded nonowner MTE2 wait queue failed the counter-bound review: its
unconsumed ready counter could grow beyond 15 over six strips. The admitted
prototype therefore has an explicit two-entry dummy-wait window. HardEvent
`MTE2_S` IDs **1 and 3** are primed once, consumed before window-slot reuse,
returned after the queued MTE2 wait, and drained once at the end. This is
explicit queue feedback, not an implicit scalar join at every generation.
The earlier proposed IDs 3/4 were corrected because the configured 950PR AKA
profile allows only 0..3. No analyzer profile override was applied.

`mode2_dummy_model.py` explores scalar source order, both free contributions,
actual panel ownership, both ready-broadcast consumers, independently progressing
MTE2 FIFO consumers, final credit drains and joins. It passes exhaustively at
1/2/6 strips: **18,097 / 49,197 / 173,613 states**, each ending in one zero-token
terminal marking. Observed maxima are AIC free credits 2, unmatched contributions
4, per-consumer ready counter 5, queued dummy waits 2. These are all below the
15-counter bound. Zero final marking with the retained per-engine drains supports
repeated-wave induction; the model is bounded evidence, not a hardware queue proof.

Three source review iterations for the mode-2 revision:

1. API/ownership: CANN 9.2.1 `kernel_event.h` admits AIV MTE2, and
   `dav_3510/kernel_operator_sync_impl.h` lowers it to the non-mode4 instructions.
   All real publications retain producer-to-scalar drains. Structural dummy
   sets require a separate manual classification, since they report no data.
2. Bounded queues/counters: fixed the unbounded dummy queue; the bounded model
   passes at the required six-strip geometry. The strip body and separate
   tail retain the baseline uniform grinder. UB remains 92,864 B including pad.
3. Static/source gate: corrected HardEvent IDs and local-symbol ambiguity;
   `aka_candidate_final.json` reports **0 fatal / 0 warnings** relative to the
   unchanged standard baseline suppression file. No tensor scalar loops or
   device PRINTF were added. Device ISA review is still required.

The hardware mode-2 map is legal, but join ID 0 is inside the shared header's
conservative reservation for hypothetical high-level Matmul objects. This
bare-Cube translation unit has no such objects in source. That observation is
not sufficient to approve simulation: compiled ISA, including `InitSocState`,
must establish no competing mode-2 ID 0 use. The completed compiled census now
does: the AIC has exactly 17 SET sites (8 readiness-8, 8 readiness-9, 1 join-0),
including all inlined startup code. Its one join0 is immediately after the
final FIX_S drain. All 36 AIV SET sites resolve to free10/free15. The linear
scanner leaves two unresolved across a branch; `branch_certificate.json`
closes them from their sole incoming 0x38c path, where X6=0xf21 and X4=0xa21,
unchanged before the SETs at0x2ec4 and0x2f54. This is a source/hash-bound local
path certificate, not a claim that the general scanner resolved all branches.
SyncAll IDs 11..14 remain unused.

**The user clarified the gate to reject new or unaccounted implicit stalls.**
This pure synchronization revision intentionally retains the baseline's direct
GM metadata loads and Checkpoint-1 proven cold `ZEROEXT` dependency stalls.
They remain quantified baseline inheritance, not an eliminated cost. The new
two-slot MTE2_S reuse waits are explicit accounted queue feedback. New scalar
control-stack traffic is counted statically in `isa_audit.json`; its dynamic
latencies must be attributed in the candidate trace. No additional metadata
optimization has been combined into this pure ablation.

The strict build completed with no warning/error lines. All 26 shared
nonentry tensor-VF functions have byte-identical instruction streams to the
baseline (`vf_byte_comparison.json`), so no new tensor spilling or scalar-UB
tensor path has been introduced. `PRE_SIM_MANIFEST.json` binds source, binary,
device objects, disassemblies, full build log and reviews. `STATUS.json` lists
the remaining model grant, bit-exactness/canaries and trace gates. No Slot06
CAModel was launched by this worker.

## Gate status

- Executable bounded ownership proof: conditional pass for consuming semantics;
  deliberate negative-control failure for sticky semantics.
- Device source/ISA scalar-order review: source complete, static ISA census and
  branch certificate complete; dynamic release and latency attribution pending.
- Implicit scalar stalls: inherited cold GM metadata stalls explicitly allowed
  for this pure ablation; new explicit window feedback accounted.
- Scalar tensor loops/device PRINTF: none introduced in the mode-2 candidate.
- AKA fatal/warning delta gate: 0 fatal / 0 warnings with unchanged suppressions.
- BiSheng: strict build PASS; CAModel: not started by this worker.

API/source evidence:

- `C:/PipeSim/docs/ascendc_api/SIMD-API/basic_api/sync_control/inter_core_sync/CrossCoreSetFlag_ISASI.md`
- `C:/PipeSim/docs/ascendc_api/SIMD-API/basic_api/sync_control/inter_core_sync/CrossCoreWaitFlag_ISASI.md`
- `C:/PipeSim/docs/ascendc_api/SIMD-API/basic_api/sync_control/inter_core_sync/key_feature_description.md`
- `/home/dmin/work/checkpoint1_20261123/architect/src/src/prefill/turboquant_reshape_batch.cpp`
- `C:/ascend-micro-harness/reports/bf16_prefill_key_plane_fix.md`

The 3510-specific local skills and API docs take precedence over the generic
910B CV-fusion examples; those examples do not establish mode-4 consumption.
