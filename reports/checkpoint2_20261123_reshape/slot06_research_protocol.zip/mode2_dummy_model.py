"""Per-owner mode2 credits with bounded dummy contributions and async MTE2 consumers.

This is a conditional protocol proof; it does not certify generated ISA or
hardware queue semantics. No device compiler or CAModel is launched.
"""
from collections import deque
import argparse,json
from pathlib import Path


def program(n):
    aic=[]
    for g in range(n):
        for owner in range(2):
            aic.extend((kind,owner,g) for kind in ("take","write","ready"))
    aic.extend(("drain",owner,-1) for owner in range(2) for _ in range(2))
    aic.append(("join",-1,-1))
    aivs=[]
    for k in range(2):
        p=[("contribute",owner,-1) for _ in range(2) for owner in range(2)]
        for g in range(n):
            p.extend((("contribute",1-k,g),("dummy_window",1-k,g),("queue_dummy_wait",1-k,g),
                      ("wait",k,g),("read",k,g),("contribute",k,g)))
        p.extend((("join_wait",k,-1),("mte2_drain",k,-1)))
        aivs.append(p)
    return (aic,*aivs)


def check(n,cap=400000):
    progs=program(n)
    # PC3, AIC free2, unmatched contributions owner*2+source, ready owner*2+consumer,
    # join2, buffer4, generation4, queued MTE2 consumer2.
    initial=((0,0,0),(0,0),(0,)*4,(0,)*4,(0,0),(0,)*4,(-1,)*4,(0,0))
    todo=deque([initial]);seen={initial};maxima=[0,0,0,0];terminals=0
    while todo:
        state=todo.popleft();pc,free,contrib,ready,join,buf,stamp,pending=state
        if all(pc[i]==len(progs[i]) for i in range(3)):
            terminals+=1
            assert not any(free+contrib+ready+join+pending)
            assert not any(buf)
            continue
        enabled=0
        for actor in range(5):
            f,c,r,j,b,s,q=map(list,(free,contrib,ready,join,buf,stamp,pending));p=list(pc)
            if actor>=3:
                k=actor-3;owner=1-k;index=owner*2+k
                if not q[k] or not r[index]:continue
                q[k]-=1;r[index]-=1
            else:
                if pc[actor]==len(progs[actor]):continue
                kind,owner,g=progs[actor][pc[actor]]
                k=actor-1;pos=owner*2+(g%2) if g>=0 else -1
                if kind in ("take","drain"):
                    if not f[owner]:continue
                    f[owner]-=1
                    if kind=="take":
                        if b[pos]!=0:return dict(pass_=False,reason="overwrite",states=len(seen))
                        b[pos]=1
                elif kind=="write":
                    assert b[pos]==1;b[pos]=2;s[pos]=g
                elif kind=="ready":
                    assert b[pos]==2
                    r[owner*2]+=1;r[owner*2+1]+=1
                elif kind=="contribute":
                    if g>=0 and owner==k:
                        assert b[pos]==3 and s[pos]==g;b[pos]=0
                    c[owner*2+k]+=1
                    if c[owner*2] and c[owner*2+1]:
                        c[owner*2]-=1;c[owner*2+1]-=1;f[owner]+=1
                elif kind=="queue_dummy_wait":q[k]+=1
                elif kind=="dummy_window":
                    # FIFO two-slot MTE2_S credits: slot(g) was returned by
                    # consumption of dummy wait g-2. Explicit source feedback.
                    if q[k]>=2:continue
                elif kind=="wait":
                    if not r[owner*2+k]:continue
                    r[owner*2+k]-=1
                    if b[pos]!=2 or s[pos]!=g:return dict(pass_=False,reason="stale read",states=len(seen))
                    b[pos]=3
                elif kind=="read":assert b[pos]==3 and s[pos]==g
                elif kind=="join":j[0]+=1;j[1]+=1
                elif kind=="join_wait":
                    if not j[k]:continue
                    j[k]-=1
                elif kind=="mte2_drain":
                    if q[k]:continue
                else:raise ValueError(kind)
                p[actor]+=1
            observed=[max(f),max(c),max(r),max(q)]
            maxima=[max(a,b) for a,b in zip(maxima,observed)]
            if max(observed[:3])>15:return dict(pass_=False,reason="counter overflow",states=len(seen))
            child=tuple(map(tuple,(p,f,c,r,j,b,s,q)));enabled+=1
            if child not in seen:seen.add(child);todo.append(child)
        if not enabled:return dict(pass_=False,reason="deadlock",states=len(seen))
        if len(seen)>cap:return dict(pass_=None,reason="state cap; no exhaustive claim",states=len(seen),maxima=maxima)
    return dict(pass_=True,states=len(seen),terminal_states=terminals,
                maxima=dict(zip(("aic_free_counter","unmatched_contribution","ready_counter","queued_dummy_waits"),maxima)))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--out",type=Path,required=True);a=p.parse_args()
    result={str(strips):check(4*strips) for strips in (1,2,6)}
    a.out.write_text(json.dumps(dict(scope="bounded exhaustive model under documented consuming mode2 semantics; independent MTE2 progress assumed",results=result),indent=2)+"\n")
    print(json.dumps(result,indent=2))
