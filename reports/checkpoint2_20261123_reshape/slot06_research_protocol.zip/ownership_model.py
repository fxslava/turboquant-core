"""Bounded per-owner mode-4 landing protocol model; no device execution.

Consuming counters are an explicit semantic hypothesis, NOT a CAModel claim.
The sticky alternative models the retained BF16 recycled-mode4 counterexample.
"""
from collections import deque
from dataclasses import dataclass
import argparse
import json
from pathlib import Path


@dataclass(frozen=True)
class Op:
    kind: str
    owner: int
    generation: int = -1
    slot: int = -1


def programs(generations):
    aic=[]
    for g in range(generations):
        for owner in range(2):
            slot=g%2
            aic.extend(Op(kind,owner,g,slot) for kind in ("wait_free","write","publish_ready"))
    for owner in range(2):
        for slot in range(2):
            aic.append(Op("drain_free",owner,slot=slot))
    aic.extend(Op("publish_join",owner) for owner in range(2))
    aivs=[]
    for owner in range(2):
        ops=[Op("prime_free",owner,slot=s) for s in range(2)]
        for g in range(generations):
            ops.extend(Op(kind,owner,g,g%2) for kind in ("wait_ready","read","return_free"))
        ops.append(Op("wait_join",owner))
        aivs.append(ops)
    return aic,*aivs


def explore(generations,consuming):
    progs=programs(generations)
    # PCs; free tokens(4); ready tokens(4); joins(2); buffer state(4), generation(4).
    initial=((0,0,0),(0,)*4,(0,)*4,(0,0),("free",)*4,(-1,)*4)
    todo=deque([initial]); seen={initial}; parent={initial:None}
    def path(state,event):
        out=[event]
        while parent[state] is not None:
            state,previous=parent[state];out.append(previous)
        return list(reversed(out))
    terminals=0
    while todo:
        state=todo.popleft(); pcs,free,ready,joins,ownership,stamps=state
        if all(pcs[r]==len(progs[r]) for r in range(3)):
            terminals+=1
            if any(free+ready+joins) or any(v!="free" for v in ownership):
                return dict(pass_=False,reason="nonempty final marking",witness=path(state,"final"),states=len(seen))
            continue
        enabled=0
        for role,prog in enumerate(progs):
            if pcs[role]==len(prog):continue
            op=prog[pcs[role]]; pos=op.owner*2+op.slot if op.slot>=0 else -1
            f,r,j,o,s=map(list,(free,ready,joins,ownership,stamps))
            event=f"role{role}:{op.kind}:owner{op.owner}:gen{op.generation}:slot{op.slot}"
            failure=None
            if op.kind in ("wait_free","drain_free"):
                if not f[pos]:continue
                if consuming:f[pos]-=1
                if op.kind=="wait_free":
                    if o[pos]!="free":failure="overwrite before owning AIV returned landing slot"
                    else:o[pos]="reserved"
            elif op.kind=="write":
                if o[pos]!="reserved":failure="write without exclusive credit"
                else:o[pos]="ready";s[pos]=op.generation
            elif op.kind=="publish_ready":
                if r[pos] and consuming:failure="ready channel exceeds capacity one"
                else:r[pos]=1
            elif op.kind=="wait_ready":
                if not r[pos]:continue
                if consuming:r[pos]-=1
                if o[pos]!="ready" or s[pos]!=op.generation:failure="stale ready notification or publication before write"
                else:o[pos]="reading"
            elif op.kind=="read":
                if o[pos]!="reading" or s[pos]!=op.generation:failure="landing read sees wrong generation"
            elif op.kind in ("return_free","prime_free"):
                if op.kind=="return_free":
                    if o[pos]!="reading":failure="free publication before landing read retired"
                    else:o[pos]="free"
                if f[pos] and consuming:failure="free channel exceeds capacity one"
                else:f[pos]=1
            elif op.kind=="publish_join":j[op.owner]+=1
            elif op.kind=="wait_join":
                if not j[op.owner]:continue
                if consuming:j[op.owner]-=1
            if failure:
                return dict(pass_=False,reason=failure,witness=path(state,event),states=len(seen))
            nextpc=list(pcs);nextpc[role]+=1
            child=(tuple(nextpc),tuple(f),tuple(r),tuple(j),tuple(o),tuple(s))
            enabled+=1
            if child not in seen:
                seen.add(child);parent[child]=(state,event);todo.append(child)
        if not enabled:
            return dict(pass_=False,reason="deadlock",witness=path(state,"no enabled transition"),states=len(seen))
    return dict(pass_=True,states=len(seen),terminal_states=terminals)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path,required=True)
    args=parser.parse_args()
    results={}
    for strips in (1,2,6):
        generations=4*strips
        results[str(strips)]=dict(generations_per_owner=generations,
            consuming=explore(generations,True),sticky=explore(generations,False))
    report=dict(scope="bounded exhaustive interleavings, publication occurs only after modeled producer retirement",
                local_ids=dict(ready=[0,1],free=[2,3],join=4),max_local_id=4,
                source_report="reports/bf16_prefill_key_plane_fix.md: recycled mode4 empirically failed despite fences",
                single_shot_required_ready_ids_six_strips=24,legal_local_ids=11,
                device_implementation_approved=False,results=results)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({k:{sem:(v[sem]['pass_'],v[sem]['states']) for sem in ('consuming','sticky')}
                      for k,v in results.items()},indent=2))


if __name__=="__main__":main()
